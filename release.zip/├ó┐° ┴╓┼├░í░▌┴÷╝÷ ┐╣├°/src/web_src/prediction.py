import numpy as np
import tensorflow as tf
import pandas as pd
import sys
#
#PREDICTION_SPLIT = 
class DataPreprocessing:
    def __init__(self, path):
        self.path = path    #인스턴스 변수 
        self.data = None    #인스턴스 변수 
        self.isdatavalid = True
        self.processeddata = None
        self.tensor = None
        
    #convert pickle to pandas dataframe & pridiction data split
    def loadData(self):
        self.data = pd.read_pickle(self.path)
        print(self.data)
        self.data['new_Date'] = pd.to_datetime(self.data['date'])
        self.data.drop('date', axis = 1, inplace=True)
        self.data.set_index('new_Date', inplace=True)
        if len(self.data) > 26:
            self.data = self.data[len(self.data)-26:]
        elif len(self.data) < 26:
            self.isdatavlid = False
            print("Input Dataset is smaller than 26rows..")
            sys.exit()
            return 'Input Dataset is smaller than 26rows..'
    # data standard
    def preprocessing(self,model_path):
        economic_stat = ['consumer_price','house_loan','building_space','interest_idx','housing_price']
        features = self.data[economic_stat]
        dataset = features.values
        print("==========================")
        print(dataset)
        data_mean = dataset.mean(axis=0)
        print("==========================")
        print(data_mean)
        data_std = dataset.std(axis=0)
        print("==========================")
        print(data_std)
        print("")
        self.processeddata = (dataset-data_mean)/data_std
        print(self.processeddata)
        print(self.processeddata.shape)
        if model_path == '3month_changwon_model_final.h5':
#        if model_path == '3month_recently.h5':
            self.processeddata = self.processeddata[-13:]    
            self.processeddata = self.processeddata.reshape(1,13,5)
        else:
            self.processeddata = self.processeddata.reshape(1,26,5)
        print(self.processeddata.shape)
        model = tf.keras.models.load_model(model_path)
        output = model.predict(self.processeddata)
        print(output)
        converted_output = np.array2string(output, separator=',')
        return converted_output

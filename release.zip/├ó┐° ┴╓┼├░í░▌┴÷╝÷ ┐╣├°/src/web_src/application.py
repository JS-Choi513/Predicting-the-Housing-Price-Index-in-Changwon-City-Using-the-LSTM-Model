from flask import Flask, flash, request, redirect, url_for
import numpy as np
import sys
from flask_restful import Api, Resource, reqparse
import tensorflow as tf
import prediction
import os
from werkzeug.utils import secure_filename
import pickle
import requests
import pandas as pd
from flask import g
import os


application = Flask(__name__)
api = Api(application)

def load_model(self, path):
    model = tf.load_model(path)
    

@application.route('/upload', methods=['POST'])
def flask_api_function():
    uploaded_data = pickle.loads(request.get_data())
    with open('predictor_API.pkl', 'wb') as f:
        pickle.dump(uploaded_data, f, pickle.HIGHEST_PROTOCOL)
    print(uploaded_data)
    return 'Ok'

@application.route('/prediction_3month', methods=['POST'])
def flask_api_function_predict():
    path = 'predictor_API.pkl'
    path_model = '3month_changwon_model_final.h5'
#    path_model = '3month_recently.h5'
    if os.path.getsize(path) > 0:      
        with open(path, "rb") as f:
            unpickler = pickle.Unpickler(f)
            predic = prediction.DataPreprocessing(path)
            predic.loadData()
            predict_data = predic.preprocessing(path_model)
    return predict_data

@application.route('/prediction_6month', methods=['POST'])
def flask_api_function_predict2():
    path = 'predictor_API.pkl'
    path_model = '6month_changwon_model_final.h5'
#    path_model = '6month_recently.h5'
    if os.path.getsize(path) > 0:      
        with open(path, "rb") as f:
            unpickler = pickle.Unpickler(f)
            predic = prediction.DataPreprocessing(path)
            predic.loadData()
            predict_data = predic.preprocessing(path_model)
    return predict_data

if __name__ == "__main__":
    application.run(host='0.0.0.0', port=int(sys.argv[1]))

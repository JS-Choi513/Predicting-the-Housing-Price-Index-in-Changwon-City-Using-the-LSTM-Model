개발자 : 최진서
E-mail : tjwjs513@gmail.com
Github : https://github.com/JS-Choi513/Predicting-the-Housing-Price-Index-in-Changwon-City-Using-the-LSTM-Model.git
License : MIT
License URI: https://opensource.org/licenses/MIT
Version : 1.0 

== Description ==
딥러닝을 활용한 창원시 주택가격지수 예측 프로그램입니다. 
-압축파일 구성요쇼-
-Housing_Index_predictor.exe
-readme.txt
-의창구_test_dataset.csv
-src--
       |
        --GUI_set.py // GUI구성 및 메인 프로그램 
       |
        --PandasModel.py // 데이터 처리모듈
       |
        --web_src-- 
      	          |
        	           --application.py // 웹서버 단에서 동작하는 API 인프라 모듈
	          |
        	           --prediction.py // 웹서버 단에서 동작하는 학습모델제어 모듈

== Installation ==
추가 설치요소 없이 .exe 파일을 실행하면 됩니다. 
Windows OS가 설치되어 있는 64비트 환경에서만 정상적으로 실행됩니다. 
반드시 인터넷이 연결되어 있는 PC 환경이어야 합니다. 

== 동작환경 테스트 결과 ==
x86-64 Window10 pro : 성공
x86-64 Window10 home : 성공
x86-64 Window7 pro : 성공
linux 환경의 경우 src 디렉터리 내 GUI_set.py 파일을 실행하시면 됩니다.

== 사용방법 ==
1.  Housing_Index_predictor.exe 더블클릭하여 프로그램 실행

2. 우측하단 데이터 예측기간(3개월, 6개월), 지역구 선택

3. 좌측상단 'file'탭으로 '의창구_test_dataset.csv' 테스트 데이터셋을 선택하여 업로드 

3. 'generate prediction' 버튼 클릭 

4. 약 8초 후 예측데이터 시각화 그래프 생성

== 주의사항 == 
반드시 예측기간과 지역을 선택한 후 데이터를 먼저 업로드해야 합니다. 
웹서버 호스팅 업체의 무료이용 정책으로 2시간마다 웹서버 세션이 닫힙니다. 
 -가능한한 수동으로 유지하고 있으나 00:00 ~ 09:00 까지 서비스 이용이 원활하지 않을 수 있습니다.  